from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, MaxPooling2D, Activation, Flatten, Dropout
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.applications.vgg16 import VGG16

class learningFam:
    def __init__(self):
        self.model_path = './data/model/reco_family.ckpt'

    def get_model(self):
        ## transfer learning
        transfer_vgg16 = VGG16(
            weights='imagenet',
            include_top=False,
            input_shape=(150, 150, 3))
        transfer_vgg16.trainable = False
        print('====== vgg16 모델을 가져 왔습니다. ========')

        model = Sequential()
        model.add(transfer_vgg16)
        model.add(Flatten())
        model.add(Dense(64, activation='relu'))
        model.add(Dropout(0.3))
        model.add(Dense(1, activation='sigmoid'))
        print('====== 학습 모델을 돌려줍니다. ========')

        return model

    def train_model(self):
        train_data_gen = ImageDataGenerator(rescale=1./255,            # 정규화
                                           horizontal_flip=True,       # 수평 뒤집기
                                           fill_mode='nearest')
        train_generator = train_data_gen.flow_from_directory('./data/train', target_size=(150, 150), batch_size=5, class_mode='binary')

        test_data_gen = ImageDataGenerator(rescale=1./255)  # 테스트 데이터는 정규화만
        test_generator = test_data_gen.flow_from_directory('./data/test', target_size=(150, 150), batch_size=5, class_mode='binary')
        print('====== vgg16 모델을 가져 옵니다. ========')

        finetune_vgg16 = self.get_model()

        print('====== 학습 모델을 Compile 합니다. ========')
        finetune_vgg16.compile(loss='binary_crossentropy', optimizer = 'adam', metrics = ['acc'])

        checkpoint = ModelCheckpoint(filepath = self.model_path, save_weights_only=True, save_best_only=True)
        erarly_stop = EarlyStopping(patience=10)

        print('====== 학습을 시작합니다. ========')
        try:
            history = finetune_vgg16.fit(train_generator,
                                         epochs=100,
                                         batch_size = 20,
                                         validation_data=test_generator,
                                         callbacks=[checkpoint, erarly_stop])
        except Exception as e:
            return e
        return None

    def get_modelpath(self):
        return self.model_path